import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Trophy, Flame, Star, TrendingUp, Calendar, Crown, Medal, Award } from "lucide-react"
import Link from "next/link"

export default function LeaderboardPage() {
  const weeklyLeaders = [
    {
      rank: 1,
      name: "Jessica Park",
      username: "@jessicap",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 3250,
      streak: 28,
      posts: 12,
      likes: 1456,
      badge: "Motivational Legend",
    },
    {
      rank: 2,
      name: "David Kim",
      username: "@davidk",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 2890,
      streak: 22,
      posts: 10,
      likes: 1234,
      badge: "Inspiration Master",
    },
    {
      rank: 3,
      name: "Alex Johnson",
      username: "@alexj",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 2450,
      streak: 15,
      posts: 8,
      likes: 987,
      badge: "Motivational Master",
    },
    {
      rank: 4,
      name: "Maria Garcia",
      username: "@mariag",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 2340,
      streak: 19,
      posts: 9,
      likes: 876,
      badge: "Daily Motivator",
    },
    {
      rank: 5,
      name: "James Wilson",
      username: "@jamesw",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 2180,
      streak: 12,
      posts: 7,
      likes: 765,
      badge: "Story Teller",
    },
  ]

  const monthlyLeaders = [
    {
      rank: 1,
      name: "Sarah Chen",
      username: "@sarahc",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 12450,
      streak: 30,
      posts: 45,
      likes: 5678,
      badge: "Motivational Legend",
    },
    {
      rank: 2,
      name: "Mike Rodriguez",
      username: "@mikerod",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 11890,
      streak: 28,
      posts: 42,
      likes: 5234,
      badge: "Inspiration Master",
    },
    {
      rank: 3,
      name: "Emma Thompson",
      username: "@emmat",
      avatar: "/placeholder.svg?height=40&width=40",
      points: 10750,
      streak: 25,
      posts: 38,
      likes: 4987,
      badge: "Community Helper",
    },
  ]

  const categories = [
    {
      name: "Most Consistent",
      icon: <Flame className="w-5 h-5" />,
      leader: "Jessica Park",
      value: "28 day streak",
      color: "text-orange-500",
    },
    {
      name: "Most Inspiring",
      icon: <Star className="w-5 h-5" />,
      leader: "Sarah Chen",
      value: "5,678 likes",
      color: "text-yellow-500",
    },
    {
      name: "Most Active",
      icon: <TrendingUp className="w-5 h-5" />,
      leader: "David Kim",
      value: "45 posts",
      color: "text-green-500",
    },
    {
      name: "Community Builder",
      icon: <Award className="w-5 h-5" />,
      leader: "Emma Thompson",
      value: "234 comments",
      color: "text-blue-500",
    },
  ]

  const achievements = [
    {
      name: "First Place",
      description: "Reached #1 on weekly leaderboard",
      icon: "🥇",
      rarity: "Legendary",
      holders: 12,
    },
    {
      name: "Streak Master",
      description: "Maintained 30+ day streak",
      icon: "🔥",
      rarity: "Epic",
      holders: 45,
    },
    {
      name: "Community Favorite",
      description: "Received 1000+ likes in a month",
      icon: "❤️",
      rarity: "Rare",
      holders: 89,
    },
    {
      name: "Motivation Machine",
      description: "Posted daily for 2 weeks straight",
      icon: "⚡",
      rarity: "Common",
      holders: 234,
    },
  ]

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-5 h-5 text-yellow-500" />
      case 2:
        return <Medal className="w-5 h-5 text-gray-400" />
      case 3:
        return <Award className="w-5 h-5 text-orange-500" />
      default:
        return <div className="w-5 h-5 flex items-center justify-center text-sm font-bold text-gray-500">#{rank}</div>
    }
  }

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200"
      case 2:
        return "bg-gradient-to-r from-gray-50 to-slate-50 border-gray-200"
      case 3:
        return "bg-gradient-to-r from-orange-50 to-red-50 border-orange-200"
      default:
        return "bg-white border-gray-200"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Leaderboard
            </span>
          </div>
          <Link href="/dashboard">
            <Button variant="ghost">Back to Feed</Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Category Leaders */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {categories.map((category, index) => (
            <Card key={index} className="text-center">
              <CardContent className="pt-6">
                <div
                  className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gray-100 flex items-center justify-center ${category.color}`}
                >
                  {category.icon}
                </div>
                <div className="font-semibold text-sm mb-1">{category.name}</div>
                <div className="text-xs text-gray-600 mb-2">{category.leader}</div>
                <Badge variant="secondary" className="text-xs">
                  {category.value}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="weekly" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="weekly">This Week</TabsTrigger>
            <TabsTrigger value="monthly">This Month</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>

          <TabsContent value="weekly" className="mt-6">
            <div className="space-y-4">
              {weeklyLeaders.map((user, index) => (
                <Card key={user.rank} className={`${getRankBg(user.rank)} hover:shadow-lg transition-shadow`}>
                  <CardContent className="pt-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-3">
                        {getRankIcon(user.rank)}
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={user.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-semibold text-lg">{user.name}</div>
                            <div className="text-sm text-gray-600">{user.username}</div>
                            <Badge className="mt-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs">
                              {user.badge}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-purple-600">{user.points}</div>
                            <div className="text-sm text-gray-500">points</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Flame className="w-4 h-4 text-orange-500 mr-1" />
                          <span className="font-semibold">{user.streak}</span>
                        </div>
                        <div className="text-xs text-gray-500">Day Streak</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Calendar className="w-4 h-4 text-blue-500 mr-1" />
                          <span className="font-semibold">{user.posts}</span>
                        </div>
                        <div className="text-xs text-gray-500">Posts</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="font-semibold">{user.likes}</span>
                        </div>
                        <div className="text-xs text-gray-500">Likes</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="monthly" className="mt-6">
            <div className="space-y-4">
              {monthlyLeaders.map((user, index) => (
                <Card key={user.rank} className={`${getRankBg(user.rank)} hover:shadow-lg transition-shadow`}>
                  <CardContent className="pt-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-3">
                        {getRankIcon(user.rank)}
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={user.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-semibold text-lg">{user.name}</div>
                            <div className="text-sm text-gray-600">{user.username}</div>
                            <Badge className="mt-1 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xs">
                              {user.badge}
                            </Badge>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-purple-600">{user.points}</div>
                            <div className="text-sm text-gray-500">points</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t">
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Flame className="w-4 h-4 text-orange-500 mr-1" />
                          <span className="font-semibold">{user.streak}</span>
                        </div>
                        <div className="text-xs text-gray-500">Day Streak</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Calendar className="w-4 h-4 text-blue-500 mr-1" />
                          <span className="font-semibold">{user.posts}</span>
                        </div>
                        <div className="text-xs text-gray-500">Posts</div>
                      </div>
                      <div className="text-center">
                        <div className="flex items-center justify-center mb-1">
                          <Star className="w-4 h-4 text-yellow-500 mr-1" />
                          <span className="font-semibold">{user.likes}</span>
                        </div>
                        <div className="text-xs text-gray-500">Likes</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="mt-6">
            <div className="grid md:grid-cols-2 gap-6">
              {achievements.map((achievement, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className="text-3xl">{achievement.icon}</div>
                      <div>
                        <CardTitle className="text-lg">{achievement.name}</CardTitle>
                        <CardDescription>{achievement.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <Badge
                        className={`${
                          achievement.rarity === "Legendary"
                            ? "bg-gradient-to-r from-yellow-500 to-orange-500"
                            : achievement.rarity === "Epic"
                              ? "bg-gradient-to-r from-purple-500 to-pink-500"
                              : achievement.rarity === "Rare"
                                ? "bg-gradient-to-r from-blue-500 to-indigo-500"
                                : "bg-gray-500"
                        } text-white`}
                      >
                        {achievement.rarity}
                      </Badge>
                      <div className="text-sm text-gray-600">{achievement.holders} holders</div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
