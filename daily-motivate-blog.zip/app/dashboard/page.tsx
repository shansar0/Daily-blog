import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Heart,
  MessageCircle,
  Share2,
  Trophy,
  Flame,
  Users,
  Plus,
  Video,
  ImageIcon,
  Calendar,
  Star,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const user = {
    name: "Alex Johnson",
    username: "@alexj",
    avatar: "/placeholder.svg?height=40&width=40",
    streak: 15,
    rank: "Motivational Master",
    points: 2450,
    followers: 1234,
    following: 567,
  }

  const posts = [
    {
      id: 1,
      author: "Sarah Chen",
      username: "@sarahc",
      avatar: "/placeholder.svg?height=40&width=40",
      time: "2 hours ago",
      content:
        "Today I finally completed my first marathon! 🏃‍♀️ It took months of training, early morning runs, and pushing through mental barriers. The feeling of crossing that finish line was indescribable. To anyone working towards a big goal - keep going, you're stronger than you think! #MarathonComplete #NeverGiveUp",
      likes: 156,
      comments: 23,
      shares: 12,
      hasVideo: false,
      badges: ["🏃‍♀️ Fitness Warrior", "🔥 15 Day Streak"],
    },
    {
      id: 2,
      author: "Mike Rodriguez",
      username: "@mikerod",
      avatar: "/placeholder.svg?height=40&width=40",
      time: "4 hours ago",
      content:
        "Started learning guitar today at 35! My fingers hurt and I can barely play a chord, but I'm excited about this new journey. It's never too late to pick up something new. What new skill are you working on? 🎸",
      likes: 89,
      comments: 31,
      shares: 8,
      hasVideo: true,
      badges: ["🎵 Creative Soul", "🌟 New Beginner"],
    },
    {
      id: 3,
      author: "Emma Thompson",
      username: "@emmat",
      avatar: "/placeholder.svg?height=40&width=40",
      time: "6 hours ago",
      content:
        "Volunteered at the local food bank today. Met so many inspiring people and heard incredible stories of resilience. Sometimes the best way to lift your own spirits is to help lift others. Grateful for this experience! 🤝❤️",
      likes: 203,
      comments: 45,
      shares: 28,
      hasVideo: false,
      badges: ["❤️ Community Helper", "🌟 Daily Motivator"],
    },
  ]

  const achievements = [
    { name: "7 Day Streak", icon: "🔥", earned: true },
    { name: "First Post", icon: "✨", earned: true },
    { name: "100 Likes", icon: "❤️", earned: true },
    { name: "Community Helper", icon: "🤝", earned: true },
    { name: "Video Creator", icon: "🎥", earned: false },
    { name: "30 Day Streak", icon: "💪", earned: false },
  ]

  const leaderboard = [
    { rank: 1, name: "Jessica Park", points: 3250, streak: 28 },
    { rank: 2, name: "David Kim", points: 2890, streak: 22 },
    { rank: 3, name: "Alex Johnson", points: 2450, streak: 15 },
    { rank: 4, name: "Maria Garcia", points: 2340, streak: 19 },
    { rank: 5, name: "James Wilson", points: 2180, streak: 12 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              DailyMotivate
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Users className="w-4 h-4 mr-2" />
              Groups
            </Button>
            <Button variant="ghost" size="sm">
              <MessageCircle className="w-4 h-4 mr-2" />
              Chat
            </Button>
            <Avatar className="w-8 h-8">
              <AvatarImage src={user.avatar || "/placeholder.svg"} />
              <AvatarFallback>AJ</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Left Sidebar - User Stats */}
          <div className="lg:col-span-1">
            <Card className="mb-6">
              <CardHeader className="text-center">
                <Avatar className="w-20 h-20 mx-auto mb-4">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>AJ</AvatarFallback>
                </Avatar>
                <CardTitle>{user.name}</CardTitle>
                <CardDescription>{user.username}</CardDescription>
                <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">{user.rank}</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Streak</span>
                    <div className="flex items-center">
                      <Flame className="w-4 h-4 text-orange-500 mr-1" />
                      <span className="font-semibold">{user.streak} days</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Points</span>
                    <div className="flex items-center">
                      <Trophy className="w-4 h-4 text-yellow-500 mr-1" />
                      <span className="font-semibold">{user.points}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Followers</span>
                    <span className="font-semibold">{user.followers}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Following</span>
                    <span className="font-semibold">{user.following}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Link href="/create-post">
                  <Button className="w-full justify-start" variant="ghost">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Post
                  </Button>
                </Link>
                <Link href="/create-vlog">
                  <Button className="w-full justify-start" variant="ghost">
                    <Video className="w-4 h-4 mr-2" />
                    Record Vlog
                  </Button>
                </Link>
                <Link href="/groups">
                  <Button className="w-full justify-start" variant="ghost">
                    <Users className="w-4 h-4 mr-2" />
                    Join Groups
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Create Post Card */}
            <Card className="mb-6">
              <CardContent className="pt-6">
                <div className="flex items-center space-x-4">
                  <Avatar>
                    <AvatarImage src={user.avatar || "/placeholder.svg"} />
                    <AvatarFallback>AJ</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <Link href="/create-post">
                      <Button variant="outline" className="w-full justify-start text-gray-500 bg-transparent">
                        What's your story today, {user.name.split(" ")[0]}?
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <Link href="/create-post">
                    <Button variant="ghost" size="sm">
                      <ImageIcon className="w-4 h-4 mr-2" />
                      Photo
                    </Button>
                  </Link>
                  <Link href="/create-vlog">
                    <Button variant="ghost" size="sm">
                      <Video className="w-4 h-4 mr-2" />
                      Video
                    </Button>
                  </Link>
                  <Link href="/create-post">
                    <Button variant="ghost" size="sm">
                      <Calendar className="w-4 h-4 mr-2" />
                      Daily Goal
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Posts Feed */}
            <div className="space-y-6">
              {posts.map((post) => (
                <Card key={post.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={post.avatar || "/placeholder.svg"} />
                          <AvatarFallback>
                            {post.author
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">{post.author}</div>
                          <div className="text-sm text-gray-500">
                            {post.username} • {post.time}
                          </div>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <Share2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-800 mb-4">{post.content}</p>

                    {post.hasVideo && (
                      <div className="bg-gray-100 rounded-lg p-8 mb-4 flex items-center justify-center">
                        <div className="text-center">
                          <Video className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-sm text-gray-500">Video content</p>
                        </div>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2 mb-4">
                      {post.badges.map((badge, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {badge}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-red-500">
                        <Heart className="w-4 h-4 mr-2" />
                        {post.likes}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-500">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        {post.comments}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-green-500">
                        <Share2 className="w-4 h-4 mr-2" />
                        {post.shares}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="lg:col-span-1">
            <Tabs defaultValue="leaderboard" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
                <TabsTrigger value="achievements">Badges</TabsTrigger>
              </TabsList>

              <TabsContent value="leaderboard">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Trophy className="w-5 h-5 mr-2 text-yellow-500" />
                      Top Motivators
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {leaderboard.map((user, index) => (
                        <div
                          key={user.rank}
                          className={`flex items-center justify-between p-2 rounded-lg ${user.rank === 3 ? "bg-purple-50 border border-purple-200" : ""}`}
                        >
                          <div className="flex items-center space-x-3">
                            <div
                              className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                                user.rank === 1
                                  ? "bg-yellow-500 text-white"
                                  : user.rank === 2
                                    ? "bg-gray-400 text-white"
                                    : user.rank === 3
                                      ? "bg-orange-500 text-white"
                                      : "bg-gray-200 text-gray-600"
                              }`}
                            >
                              {user.rank}
                            </div>
                            <div>
                              <div className="font-medium text-sm">{user.name}</div>
                              <div className="text-xs text-gray-500 flex items-center">
                                <Flame className="w-3 h-3 mr-1" />
                                {user.streak} days
                              </div>
                            </div>
                          </div>
                          <div className="text-sm font-semibold text-purple-600">{user.points}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="achievements">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center">
                      <Star className="w-5 h-5 mr-2 text-yellow-500" />
                      Achievements
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-3">
                      {achievements.map((achievement, index) => (
                        <div
                          key={index}
                          className={`p-3 rounded-lg border text-center ${
                            achievement.earned
                              ? "bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200"
                              : "bg-gray-50 border-gray-200 opacity-50"
                          }`}
                        >
                          <div className="text-2xl mb-1">{achievement.icon}</div>
                          <div className="text-xs font-medium">{achievement.name}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            {/* Motivation Wall */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-green-500" />
                  Today's Motivation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-4 rounded-lg">
                  <p className="text-sm italic text-gray-700 mb-2">
                    "The only way to do great work is to love what you do."
                  </p>
                  <p className="text-xs text-gray-500">- Featured from @sarahc's marathon post</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
