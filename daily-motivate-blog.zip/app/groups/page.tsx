import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Search, Plus, TrendingUp, MessageCircle, Crown, Flame } from "lucide-react"
import Link from "next/link"

export default function GroupsPage() {
  const myGroups = [
    {
      id: 1,
      name: "Marathon Runners",
      description: "Training together for our next big race",
      members: 1234,
      posts: 89,
      image: "/placeholder.svg?height=60&width=60",
      category: "Fitness",
      isAdmin: true,
      lastActivity: "2 hours ago",
    },
    {
      id: 2,
      name: "Daily Gratitude",
      description: "Sharing what we're grateful for each day",
      members: 567,
      posts: 156,
      image: "/placeholder.svg?height=60&width=60",
      category: "Mindfulness",
      isAdmin: false,
      lastActivity: "5 hours ago",
    },
    {
      id: 3,
      name: "Career Growth",
      description: "Supporting each other's professional journey",
      members: 892,
      posts: 234,
      image: "/placeholder.svg?height=60&width=60",
      category: "Professional",
      isAdmin: false,
      lastActivity: "1 day ago",
    },
  ]

  const suggestedGroups = [
    {
      id: 4,
      name: "Morning Routine Masters",
      description: "Early birds sharing their morning rituals and productivity tips",
      members: 2341,
      posts: 445,
      image: "/placeholder.svg?height=60&width=60",
      category: "Productivity",
      trending: true,
    },
    {
      id: 5,
      name: "Creative Writers",
      description: "A community for aspiring and experienced writers to share and grow",
      members: 1567,
      posts: 678,
      image: "/placeholder.svg?height=60&width=60",
      category: "Creativity",
      trending: false,
    },
    {
      id: 6,
      name: "Healthy Cooking",
      description: "Sharing recipes, meal prep ideas, and nutrition tips",
      members: 3456,
      posts: 892,
      image: "/placeholder.svg?height=60&width=60",
      category: "Health",
      trending: true,
    },
    {
      id: 7,
      name: "Meditation & Mindfulness",
      description: "Daily meditation practice and mindfulness techniques",
      members: 2789,
      posts: 567,
      image: "/placeholder.svg?height=60&width=60",
      category: "Wellness",
      trending: false,
    },
  ]

  const categories = [
    { name: "All", count: 150 },
    { name: "Fitness", count: 25 },
    { name: "Mindfulness", count: 18 },
    { name: "Professional", count: 22 },
    { name: "Creativity", count: 15 },
    { name: "Health", count: 20 },
    { name: "Learning", count: 12 },
    { name: "Travel", count: 8 },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Groups
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost">Back to Feed</Button>
            </Link>
            <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Group
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Search and Filters */}
        <div className="mb-6">
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between mb-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input placeholder="Search groups..." className="pl-10" />
            </div>
            <div className="flex space-x-2">
              {categories.slice(0, 4).map((category) => (
                <Button key={category.name} variant="outline" size="sm">
                  {category.name} ({category.count})
                </Button>
              ))}
            </div>
          </div>
        </div>

        <Tabs defaultValue="my-groups" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="my-groups">My Groups</TabsTrigger>
            <TabsTrigger value="discover">Discover</TabsTrigger>
            <TabsTrigger value="trending">Trending</TabsTrigger>
          </TabsList>

          <TabsContent value="my-groups" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {myGroups.map((group) => (
                <Card key={group.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={group.image || "/placeholder.svg"} />
                        <AvatarFallback>
                          {group.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-lg">{group.name}</CardTitle>
                          {group.isAdmin && <Crown className="w-4 h-4 text-yellow-500" />}
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {group.category}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>{group.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {group.members} members
                      </div>
                      <div className="flex items-center">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        {group.posts} posts
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mb-4">Last activity: {group.lastActivity}</div>
                    <Link href={`/groups/${group.id}`}>
                      <Button className="w-full">View Group</Button>
                    </Link>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="discover" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {suggestedGroups.map((group) => (
                <Card key={group.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-12 h-12">
                        <AvatarImage src={group.image || "/placeholder.svg"} />
                        <AvatarFallback>
                          {group.name
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <CardTitle className="text-lg">{group.name}</CardTitle>
                          {group.trending && <TrendingUp className="w-4 h-4 text-green-500" />}
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {group.category}
                        </Badge>
                      </div>
                    </div>
                    <CardDescription>{group.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {group.members} members
                      </div>
                      <div className="flex items-center">
                        <MessageCircle className="w-4 h-4 mr-1" />
                        {group.posts} posts
                      </div>
                    </div>
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Join Group
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="mt-6">
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
                <CardHeader>
                  <CardTitle className="flex items-center text-orange-700">
                    <Flame className="w-5 h-5 mr-2" />
                    Hottest Groups This Week
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {suggestedGroups
                      .filter((g) => g.trending)
                      .map((group, index) => (
                        <div key={group.id} className="flex items-center space-x-4 p-3 bg-white rounded-lg">
                          <div className="w-8 h-8 bg-orange-500 text-white rounded-full flex items-center justify-center font-bold text-sm">
                            {index + 1}
                          </div>
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={group.image || "/placeholder.svg"} />
                            <AvatarFallback>
                              {group.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="font-semibold">{group.name}</div>
                            <div className="text-sm text-gray-600">{group.members} members</div>
                          </div>
                          <Button size="sm" variant="outline">
                            Join
                          </Button>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {suggestedGroups.map((group) => (
                  <Card key={group.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={group.image || "/placeholder.svg"} />
                          <AvatarFallback>
                            {group.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <CardTitle className="text-lg">{group.name}</CardTitle>
                            {group.trending && <Badge className="bg-green-100 text-green-700">Hot</Badge>}
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {group.category}
                          </Badge>
                        </div>
                      </div>
                      <CardDescription>{group.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {group.members} members
                        </div>
                        <div className="flex items-center">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          {group.posts} posts
                        </div>
                      </div>
                      <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                        <Plus className="w-4 h-4 mr-2" />
                        Join Group
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
