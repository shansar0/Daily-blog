import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Heart,
  MessageCircle,
  Share2,
  Trophy,
  Flame,
  Calendar,
  MapPin,
  LinkIcon,
  UserPlus,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"

export default function ProfilePage({ params }: { params: { username: string } }) {
  const user = {
    name: "Sarah Chen",
    username: "@sarahc",
    avatar: "/placeholder.svg?height=120&width=120",
    bio: "Marathon runner 🏃‍♀️ | Fitness enthusiast | Spreading positivity one story at a time | Living my best life every day ✨",
    location: "San Francisco, CA",
    website: "sarahfitness.com",
    joinDate: "March 2023",
    streak: 28,
    rank: "Motivational Legend",
    points: 3250,
    followers: 2456,
    following: 892,
    posts: 156,
    isFollowing: false,
  }

  const achievements = [
    { name: "Marathon Finisher", icon: "🏃‍♀️", description: "Completed first marathon", earned: true },
    { name: "30 Day Streak", icon: "🔥", description: "Posted for 30 consecutive days", earned: true },
    { name: "Community Hero", icon: "🦸‍♀️", description: "Helped 100+ people", earned: true },
    { name: "Video Creator", icon: "🎥", description: "Created 50+ videos", earned: true },
    { name: "Fitness Guru", icon: "💪", description: "Fitness category leader", earned: true },
    { name: "Inspiration Master", icon: "✨", description: "1000+ likes received", earned: true },
  ]

  const posts = [
    {
      id: 1,
      time: "2 hours ago",
      content:
        "Today I finally completed my first marathon! 🏃‍♀️ It took months of training, early morning runs, and pushing through mental barriers. The feeling of crossing that finish line was indescribable. To anyone working towards a big goal - keep going, you're stronger than you think! #MarathonComplete #NeverGiveUp",
      likes: 156,
      comments: 23,
      shares: 12,
      hasVideo: false,
      mood: "🏆 Accomplished",
    },
    {
      id: 2,
      time: "1 day ago",
      content:
        "Week 16 of marathon training complete! Today was a 20-mile long run and I'm feeling stronger than ever. The mental game is just as important as the physical preparation. Visualization and positive self-talk have been game changers for me. What mental strategies work for you? 🧠💪",
      likes: 89,
      comments: 31,
      shares: 8,
      hasVideo: true,
      mood: "🚀 Motivated",
    },
    {
      id: 3,
      time: "3 days ago",
      content:
        "Rest day doesn't mean lazy day! Spent the morning doing yoga and meditation, then meal prepped for the week. Sometimes the best thing you can do for your goals is to slow down and take care of yourself. Self-care is not selfish! 🧘‍♀️🥗",
      likes: 203,
      comments: 45,
      shares: 28,
      hasVideo: false,
      mood: "😌 Peaceful",
    },
  ]

  const stats = [
    { label: "Total Posts", value: user.posts },
    { label: "Streak Days", value: user.streak },
    { label: "Total Likes", value: "12.5K" },
    { label: "Comments", value: "3.2K" },
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
              <Flame className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              DailyMotivate
            </span>
          </div>
          <Link href="/dashboard">
            <Button variant="ghost">Back to Feed</Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Profile Header */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
              <Avatar className="w-32 h-32">
                <AvatarImage src={user.avatar || "/placeholder.svg"} />
                <AvatarFallback className="text-2xl">SC</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4">
                  <div>
                    <h1 className="text-2xl font-bold">{user.name}</h1>
                    <p className="text-gray-600">{user.username}</p>
                    <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white mt-2">{user.rank}</Badge>
                  </div>
                  <div className="flex space-x-2 mt-4 sm:mt-0">
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                      <UserPlus className="w-4 h-4 mr-2" />
                      {user.isFollowing ? "Following" : "Follow"}
                    </Button>
                    <Button variant="outline">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Message
                    </Button>
                  </div>
                </div>

                <p className="text-gray-700 mb-4">{user.bio}</p>

                <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 mb-4">
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1" />
                    {user.location}
                  </div>
                  <div className="flex items-center">
                    <LinkIcon className="w-4 h-4 mr-1" />
                    <a href={`https://${user.website}`} className="text-blue-600 hover:underline">
                      {user.website}
                    </a>
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-1" />
                    Joined {user.joinDate}
                  </div>
                </div>

                <div className="flex space-x-6 text-sm">
                  <div>
                    <span className="font-semibold">{user.followers}</span>
                    <span className="text-gray-600 ml-1">followers</span>
                  </div>
                  <div>
                    <span className="font-semibold">{user.following}</span>
                    <span className="text-gray-600 ml-1">following</span>
                  </div>
                  <div className="flex items-center">
                    <Flame className="w-4 h-4 text-orange-500 mr-1" />
                    <span className="font-semibold">{user.streak}</span>
                    <span className="text-gray-600 ml-1">day streak</span>
                  </div>
                  <div className="flex items-center">
                    <Trophy className="w-4 h-4 text-yellow-500 mr-1" />
                    <span className="font-semibold">{user.points}</span>
                    <span className="text-gray-600 ml-1">points</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="pt-6 text-center">
                <div className="text-2xl font-bold text-purple-600">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Content Tabs */}
        <Tabs defaultValue="posts" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="posts">Posts</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="mt-6">
            <div className="space-y-6">
              {posts.map((post) => (
                <Card key={post.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar>
                          <AvatarImage src={user.avatar || "/placeholder.svg"} />
                          <AvatarFallback>SC</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold">{user.name}</div>
                          <div className="text-sm text-gray-500">
                            {user.username} • {post.time}
                          </div>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {post.mood}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-800 mb-4">{post.content}</p>

                    {post.hasVideo && (
                      <div className="bg-gray-100 rounded-lg p-8 mb-4 flex items-center justify-center">
                        <div className="text-center">
                          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-2">
                            <div className="w-0 h-0 border-l-[8px] border-l-purple-600 border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                          </div>
                          <p className="text-sm text-gray-500">Training Video</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-4 border-t">
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-red-500">
                        <Heart className="w-4 h-4 mr-2" />
                        {post.likes}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-blue-500">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        {post.comments}
                      </Button>
                      <Button variant="ghost" size="sm" className="text-gray-600 hover:text-green-500">
                        <Share2 className="w-4 h-4 mr-2" />
                        {post.shares}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="mt-6">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {achievements.map((achievement, index) => (
                <Card key={index} className="bg-gradient-to-br from-purple-50 to-blue-50 border-purple-200">
                  <CardContent className="pt-6 text-center">
                    <div className="text-4xl mb-3">{achievement.icon}</div>
                    <div className="font-semibold text-purple-700 mb-1">{achievement.name}</div>
                    <div className="text-sm text-purple-600">{achievement.description}</div>
                    <Badge className="mt-3 bg-purple-600 text-white">Earned</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="activity" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Trophy className="w-4 h-4 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium">Earned "Marathon Finisher" badge</div>
                      <div className="text-sm text-gray-500">2 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Heart className="w-4 h-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="font-medium">Received 156 likes on marathon post</div>
                      <div className="text-sm text-gray-500">3 hours ago</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <Flame className="w-4 h-4 text-purple-600" />
                    </div>
                    <div>
                      <div className="font-medium">Extended streak to 28 days</div>
                      <div className="text-sm text-gray-500">1 day ago</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
