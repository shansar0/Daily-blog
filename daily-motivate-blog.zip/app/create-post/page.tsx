"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, ImageIcon, Video, Smile, Target, Send, Plus } from "lucide-react"
import Link from "next/link"

export default function CreatePost() {
  const [postContent, setPostContent] = useState("")
  const [postTitle, setPostTitle] = useState("")
  const [selectedMood, setSelectedMood] = useState("")
  const [selectedGoal, setSelectedGoal] = useState("")
  const [tags, setTags] = useState<string[]>([])
  const [newTag, setNewTag] = useState("")

  const user = {
    name: "Alex Johnson",
    username: "@alexj",
    avatar: "/placeholder.svg?height=40&width=40",
  }

  const moods = [
    { value: "motivated", label: "🚀 Motivated", color: "bg-green-100 text-green-700" },
    { value: "grateful", label: "🙏 Grateful", color: "bg-blue-100 text-blue-700" },
    { value: "accomplished", label: "🏆 Accomplished", color: "bg-yellow-100 text-yellow-700" },
    { value: "reflective", label: "🤔 Reflective", color: "bg-purple-100 text-purple-700" },
    { value: "excited", label: "✨ Excited", color: "bg-pink-100 text-pink-700" },
    { value: "peaceful", label: "😌 Peaceful", color: "bg-indigo-100 text-indigo-700" },
  ]

  const goalCategories = [
    "Health & Fitness",
    "Career & Work",
    "Personal Growth",
    "Relationships",
    "Learning & Skills",
    "Creativity",
    "Travel & Adventure",
    "Financial Goals",
  ]

  const addTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim())) {
      setTags([...tags, newTag.trim()])
      setNewTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
  }

  const handleSubmit = () => {
    // Handle post submission
    console.log({
      title: postTitle,
      content: postContent,
      mood: selectedMood,
      goal: selectedGoal,
      tags: tags,
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <h1 className="text-xl font-semibold">Share Your Story</h1>
          </div>
          <Button
            onClick={handleSubmit}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Send className="w-4 h-4 mr-2" />
            Share Story
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-4xl">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={user.avatar || "/placeholder.svg"} />
                    <AvatarFallback>AJ</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">{user.name}</CardTitle>
                    <CardDescription>{user.username}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Post Title */}
                <div>
                  <Label htmlFor="title" className="text-sm font-medium mb-2 block">
                    Story Title (Optional)
                  </Label>
                  <Input
                    id="title"
                    placeholder="Give your story a catchy title..."
                    value={postTitle}
                    onChange={(e) => setPostTitle(e.target.value)}
                    className="text-lg"
                  />
                </div>

                {/* Post Content */}
                <div>
                  <Label htmlFor="content" className="text-sm font-medium mb-2 block">
                    Your Story
                  </Label>
                  <Textarea
                    id="content"
                    placeholder="What happened today? Share your experiences, thoughts, achievements, or challenges. Your story might inspire someone else!"
                    value={postContent}
                    onChange={(e) => setPostContent(e.target.value)}
                    className="min-h-[200px] text-base"
                  />
                  <div className="text-sm text-gray-500 mt-2">{postContent.length}/2000 characters</div>
                </div>

                {/* Media Upload */}
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <div className="flex justify-center space-x-4 mb-4">
                    <Button variant="outline" size="sm">
                      <ImageIcon className="w-4 h-4 mr-2" />
                      Add Photo
                    </Button>
                    <Button variant="outline" size="sm">
                      <Video className="w-4 h-4 mr-2" />
                      Add Video
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">Drag and drop files here, or click to browse</p>
                </div>

                {/* Tags */}
                <div>
                  <Label className="text-sm font-medium mb-2 block">Tags</Label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
                        #{tag} ×
                      </Badge>
                    ))}
                  </div>
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Add a tag..."
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addTag()}
                      className="flex-1"
                    />
                    <Button onClick={addTag} variant="outline" size="sm">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-6">
              {/* Mood Selector */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Smile className="w-5 h-5 mr-2" />
                    How are you feeling?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {moods.map((mood) => (
                      <Button
                        key={mood.value}
                        variant={selectedMood === mood.value ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedMood(mood.value)}
                        className={`justify-start text-xs ${selectedMood === mood.value ? "bg-gradient-to-r from-purple-600 to-blue-600" : ""}`}
                      >
                        {mood.label}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Goal Tracker */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Target className="w-5 h-5 mr-2" />
                    Related to a goal?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Select value={selectedGoal} onValueChange={setSelectedGoal}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {goalCategories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>

              {/* Quick Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">💡 Writing Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm space-y-2 text-gray-600">
                    <li>• Be authentic and honest</li>
                    <li>• Share specific details</li>
                    <li>• Include what you learned</li>
                    <li>• Mention challenges overcome</li>
                    <li>• End with encouragement</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Streak Reminder */}
              <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl mb-2">🔥</div>
                    <div className="font-semibold text-orange-700">15 Day Streak!</div>
                    <div className="text-sm text-orange-600">Keep it going!</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
